# 热力循环设计前端原型

## 代码

使用Modelica的设备mo文件，让deepseek分析，然后，分离模块实现

**功能**：基本原型，体现前端软件基本架构用

* js/devices： 设备类
* manager:   设备连接，文件管理，设备注册
* config:  设备类注册用json,用于配置系统中支持的设备数据
* main.js： 主程序
* RankineCycle.html 工作页面